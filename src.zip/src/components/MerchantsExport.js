// src/components/MerchantsExport.js

import React from 'react';
import axios from 'axios';

const MerchantsExport = () => {

    const handleExport = async () => {
        const token = localStorage.getItem('token');
        if (!token) {
            alert('Authentification requise pour exporter les données.');
            return;
        }

        try {
            const response = await axios.get('http://localhost:5000/api/merchants/export', {
                headers: {
                    'x-auth-token': token
                },
                responseType: 'blob'
            });

            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'merchants_export.xlsx');
            document.body.appendChild(link);
            link.click();
            link.parentNode.removeChild(link);
            window.URL.revokeObjectURL(url);

            alert('Exportation réussie !');
        } catch (error) {
            console.error("Erreur lors de l'exportation :", error);
            alert('Erreur lors de l\'exportation des marchands.');
        }
    };

    return (
        <button
            onClick={handleExport}
            className="btn-export"
        >
            Exporter les marchands
        </button>
    );
};

export default MerchantsExport;