import React from 'react';
import { Navigate } from 'react-router-dom';

const PrivateRoute = ({ children, role }) => {
  const token = localStorage.getItem('token');
  const userRole = localStorage.getItem('userRole');

  if (!token) {
    // Si pas de token, redirige vers la page de connexion
    return <Navigate to="/login" />;
  }

  // Si un rôle est requis et que le rôle de l'utilisateur ne correspond pas, redirigez
  if (role && userRole !== role) {
    // Vous pouvez créer une page d'accès refusé ou simplement rediriger vers le tableau de bord par défaut
    return <Navigate to="/" />; 
  }

  // Si tout est bon, affiche les enfants (le composant de la page)
  return children;
};

export default PrivateRoute;
