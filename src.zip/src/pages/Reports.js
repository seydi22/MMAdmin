// src/pages/Reports.js

import React from 'react';
import Sidebar from '../components/Sidebar';
import MerchantsExport from '../components/MerchantsExport'; // Import du composant d'exportation
import './Dashboard.css'; // On réutilise les styles pour le layout

const Reports = () => {
  return (
    <div className="dashboard-layout">
      <Sidebar />
      <div className="main-content">
        <header className="main-header">
          <h2>Rapports</h2>
        </header>
        <div className="placeholder-content">
            <p>La page des rapports est en cours de développement. Vous pouvez néanmoins exporter la liste des marchands.</p>
            {/* Intégration du bouton d'exportation */}
            <div style={{ marginTop: '20px' }}>
                <MerchantsExport />
            </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;