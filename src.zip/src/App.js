// src/App.js

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PrivateRoute from './components/PrivateRoute'; // Importez le PrivateRoute
import Login from './pages/Login'; // Importez la page de connexion
import Dashboard from './pages/Dashboard';
import SupervisorForm from './pages/SupervisorForm';
import Merchants from './pages/Merchants'; // Import de la nouvelle page
import MerchantDetail from './pages/MerchantDetail'; // Page de détails à venir
import Agents from './pages/Agents'; // Import de la nouvelle page
import Reports from './pages/Reports';
import Supervisors from './pages/Supervisors';
import SupervisorDashboard from './pages/SupervisorDashboard'; // Importez la nouvelle page du tableau de bord du superviseur

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />

        {/* Routes privées, accessibles uniquement si un token est présent */}
        <Route
          path="/"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />
        {/* Nouvelle route pour le tableau de bord du superviseur */}
        <Route
          path="/supervisor"
          element={
            <PrivateRoute>
              <SupervisorDashboard />
            </PrivateRoute>
          }
        />
        <Route path="/supervisors" element={<PrivateRoute><Supervisors /></PrivateRoute>} />
        <Route
          path="/supervisors/new"
          element={
            <PrivateRoute>
              <SupervisorForm />
            </PrivateRoute>
          }
        />
        <Route
          path="/supervisors/edit/:id"
          element={
            <PrivateRoute>
              <SupervisorForm />
            </PrivateRoute>
          }
        />
        <Route path="/merchants" element={<PrivateRoute><Merchants /></PrivateRoute>} />
        <Route path="/merchants/:id" element={<PrivateRoute><MerchantDetail /></PrivateRoute>} />
        <Route path="/agents" element={<PrivateRoute><Agents /></PrivateRoute>} />
        <Route path="/reports" element={<PrivateRoute><Reports /></PrivateRoute>} />
      </Routes>
    </Router>
  );
}

export default App;
